# todo/urls.py
from django.urls import reverse, include
from django.urls import path
from . import views
import os
from django.http import HttpResponseRedirect
from .views import edit_document, view_documents
from django.contrib.auth import views as auth_views


app_name = 'todo'

urlpatterns = [

    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),

    path('upload/', views.upload_document, name='upload_document'),
    path('search_documents/', views.search_documents, name='search_documents'),
    path('upload_document/', views.upload_document, name='document_upload'),
    path('preview/<str:pdf_path>/', views.pdf_view, name='pdf_view'),
    path('view_documents/', views.view_documents, name='view_documents'),
    path('edit_document/<int:pk>/', views.edit_document, name='edit_document'),
    path('delete_document/<str:filename>/', views.delete_document, name='delete_document'),
    path('update_documents/', views.update_documents, name='update_documents'),


    ]




# todo/views.py
import os
from django.conf import settings
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.shortcuts import render, redirect, get_object_or_404
from .forms import DocumentForm
from .models import Document
from django.http import HttpResponse
import requests
from .utils import summarize_pdf
import json
from PyPDF2 import PdfReader, PdfFileReader
from django.http import JsonResponse
import json
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
def home(request):
    return render(request, 'todo/home.html')

def upload_document(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():

            form.save()
            return HttpResponse("Upload successful!")
    else:
        form = DocumentForm()
    return render(request, 'todo/document_upload.html', {'form': form})

from django.http import FileResponse

def pdf_view(request, pdf_path):
    try:
        return FileResponse(open(pdf_path, 'rb'), content_type='application/pdf')
    except FileNotFoundError:
        raise Http404()

def view_documents(request):
    documents = Document.objects.all()

    documents_dir = os.path.join(settings.MEDIA_ROOT, 'documents')
    document_files = [{'name': f, 'path': os.path.join(documents_dir, f)} for f in os.listdir(documents_dir) if os.path.isfile(os.path.join(documents_dir, f))]

    ll = []
    # Generate summaries for each document
    for document in document_files:
        for doc in documents:
            n = doc.pdf_file.name.replace("/", '\\')
            if document['path'].find(n) != -1:
                summary = ""
                if doc.summary == None:
                    summary = summarize_pdf(document['path'])
                    Document.objects.filter(notes=doc.notes).filter(title=doc.title).update(summary=summary)
                else:
                    summary = doc.summary
                ll.append({
                    "title": doc.title,
                    "file": document['name'],
                    "notes": doc.notes,
                    "summary": summary
                })

    return render(request, 'todo/view_documents.html', {'documents': ll})

def extract_text_from_pdf(file_path):
    """Extract text from the PDF file specified by file_path."""
    with open(file_path, 'rb') as file:
        reader = PdfReader(file)
        text = ''
        for page in reader.pages:
            extracted_text = page.extract_text()
            if extracted_text:
                text += extracted_text
        return text

def summarize_pdf(file_path):
    pdf_content = extract_text_from_pdf(file_path)

    url = "http://localhost:11434/api/generate"
    payload = {"model": "llama3", "prompt": f"Please summarize the following text:\n\n{pdf_content}"}
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, json=payload, headers=headers)

    try:
        # Attempt to decode the full response if it's properly formatted
        response_data = response.json()
        return response_data.get('response', 'No summary provided.')
    except json.JSONDecodeError:
        # Handle cases where the JSON is not properly formatted
        try:
            # Try to manually split and parse each JSON object
            parts = response.text.split('\n')
            summaries = [json.loads(part).get('response', 'No summary in this part') for part in parts if part.strip()]
            return " ".join(summaries)
        except Exception as e:
            return "Failed to generate summary due to JSON parsing error."

def to_bibtex(file_path):
    pdf_content = extract_text_from_pdf(file_path)

    url = "http://localhost:11434/api/generate"
    payload = {"model": "llama3", "prompt": f"Please summarize the following text:\n\n{pdf_content}"}
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, json=payload, headers=headers)

    try:
        # Attempt to decode the full response if it's properly formatted
        response_data = response.json()
        return response_data.get('response', 'No summary provided.')
    except json.JSONDecodeError:
        # Handle cases where the JSON is not properly formatted
        try:
            # Try to manually split and parse each JSON object
            parts = response.text.split('\n')
            summaries = [json.loads(part).get('response', 'No summary in this part') for part in parts if part.strip()]
            return " ".join(summaries)
        except Exception as e:
            return "Failed to generate summary due to JSON parsing error."


def delete_document(request, filename):
    file_path = os.path.join(settings.MEDIA_ROOT, 'documents', filename)
    if os.path.isfile(file_path):
        os.remove(file_path)
    return HttpResponseRedirect(reverse('view_documents'))

def edit_document(request, pk):
    document = get_object_or_404(Document, pk=pk)
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES, instance=document)
        if form.is_valid():
            form.save()
            return redirect('todo:view_documents')
        else:
            # Return an error message or handle form errors
            pass
    else:
        form = DocumentForm(instance=document)

    return render(request, 'todo/edit_document.html', {'document': document, 'form': form})


def get_summary_from_ollama(text):
    url = "http://localhost:11434/api/generate"
    payload = {"model": "llama3",
               "prompt": f"读取这段文献:\n\n{text}，\n\n给我提取title,author,journal,year,volume,number,institution,abstract, 只需要返回一个json格式的数据，不需要任何其他解释"}
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, json=payload, headers=headers)

    try:
        # Attempt to decode the full response if it's properly formatted
        response_data = response.json()
        return response_data.get('response', 'No summary provided.')
    except json.JSONDecodeError:
        # Handle cases where the JSON is not properly formatted
        try:
            # Try to manually split and parse each JSON object
            parts = response.text.split('\n')
            summaries = [json.loads(part).get('response', 'No summary in this part') for part in parts if part.strip()]
            return " ".join(summaries)
        except Exception as e:
            return "Failed to generate summary due to JSON parsing error."


def search_documents(request):



    if request.method == "GET":
        return render(request, 'todo/search_documents.html')
    else:  # if data submitted
        action = json.loads(request.body).get('action')
        if action == 'openfile':
            path = json.loads(request.body).get('path')
            dd = extract_text_from_pdf(path)
            return JsonResponse(dd, safe=False)
        notes = json.loads(request.body).get('notes')
        title = json.loads(request.body).get('title')

        documents = Document.objects.all()
        list = []
        for doc in documents:
            summary = ""
            if doc.summary != None:
                summary = doc.summary
            if doc.title.find(title) != -1 and title != '':
                try:
                    n = doc.pdf_file.name.replace("/", '\\')

                    file_path = os.path.join(settings.MEDIA_ROOT, '', n)
                    pdf_content = extract_text_from_pdf(file_path)
                    list.append({
                        "content": get_summary_from_ollama(pdf_content),
                        "summary": summary,
                        "path": file_path,
                    })
                except:
                    print("error")
            elif doc.notes.find(notes) != -1 and notes != '':
                try:
                    n = doc.pdf_file.name.replace("/", '\\')
                    file_path = os.path.join(settings.MEDIA_ROOT, '', n)
                    pdf_content = extract_text_from_pdf(file_path)
                    list.append({
                        "summary": summary,
                        "content": get_summary_from_ollama(pdf_content),
                        "path": file_path,
                    })
                except:
                    print("error")


        if action == 'search':
            return JsonResponse(json.dumps(list), safe=False)



        return render(request, 'todo/search_documents.html')


def update_documents(request):
    if request.method == 'POST':
        document_ids = request.POST.getlist('document_id')
        for doc_id in document_ids:
            document = get_object_or_404(Document, pk=doc_id)
            form = DocumentForm(request.POST, request.FILES, instance=document, prefix=str(doc_id))
            if form.is_valid():
                form.save()
            else:
                # If the form is not valid, optionally handle errors here
                pass
        return redirect('todo:view_documents')
    return HttpResponseRedirect(reverse('todo:edit_document'))  # Redirect if not POST or no data

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('todo:home')
        else:
            return render(request, 'todo/login.html', {'form': form})
    else:
        form = AuthenticationForm()
        return render(request, 'todo/login.html', {'form': form})


def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('todo:home')
        else:
            return render(request, 'todo/register.html', {'form': form})
    else:
        form = UserCreationForm()
        return render(request, 'todo/register.html', {'form': form})
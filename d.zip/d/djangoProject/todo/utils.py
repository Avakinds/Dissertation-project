import requests
import json
import logging
from PyPDF2 import PdfReader

# Setup logging
logging.basicConfig(level=logging.DEBUG)

def extract_text_from_pdf(file_path):
    """Extract text from the PDF file specified by file_path."""
    with open(file_path, 'rb') as file:
        reader = PdfReader(file)
        text = ''
        for page in reader.pages:
            extracted_text = page.extract_text()
            if extracted_text:
                text += extracted_text
        return text

def get_summary_from_ollama(text):
    """Post the extracted text to the API and handle the JSON response more robustly."""
    url = "http://localhost:11434/api/generate"
    payload = {"model": "llama3", "prompt": f"Please summarize the following text:\n\n{text}"}
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, json=payload, headers=headers)

    try:
        # Attempt to decode the full response if it's properly formatted
        response_data = response.json()
        return response_data.get('response', 'No summary provided.')
    except json.JSONDecodeError:
        # Handle cases where the JSON is not properly formatted
        try:
            # Try to manually split and parse each JSON object
            parts = response.text.split('\n')
            summaries = [json.loads(part).get('response', 'No summary in this part') for part in parts if part.strip()]
            return " ".join(summaries)
        except Exception as e:
            logging.error(f"Failed to parse JSON: {e}")
            return "Failed to generate summary due to JSON parsing error."

def summarize_pdf(file_path):
    """Extract text from a PDF and summarize it using an external API."""
    text = extract_text_from_pdf(file_path)
    if text:
        return get_summary_from_ollama(text)
    else:
        return "Failed to extract text from PDF."

# Example usage
# test_pdf_path = r'/Users/trait/Downloads/p1/djangoProject/media/documents/example01.pdf'
# summary = summarize_pdf(test_pdf_path)
# print("Summary:", summary)

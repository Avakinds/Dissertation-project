import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'djangoProject.settings')
django.setup()

from todo.models import Document
def list_documents():
    documents = Document.objects.all()
    for doc in documents:
        print(f"Title: {doc.title}, File: {doc.pdf_file}, Summary: {doc.summary}, Notes: {doc.notes}")

if __name__ == '__main__':
    list_documents()

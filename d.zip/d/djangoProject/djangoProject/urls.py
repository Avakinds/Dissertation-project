# todo/urls.py
from django.urls import reverse, include
from django.urls import path
import os
from django.http import HttpResponseRedirect
from todo import views

app_name = 'todo'

urlpatterns = [


    path('', include(('todo.urls', 'todo'), namespace='todo')),  # Changed from 'todo/' to ''
    path('delete_document/<str:filename>/', views.delete_document, name='delete_document'),
    path('upload/', views.upload_document, name='upload_document'),
    path('upload_document/', views.upload_document, name='document_upload'),
    path('view_documents/', views.view_documents, name='view_documents'),
    path('search_documents/', views.search_documents, name='search_documents'),
    path('preview/<str:pdf_path>', views.pdf_view, name='pdf_view'),
    path('edit_document/<int:pk>/', views.edit_document, name='edit_document'),
    path('update_documents/', views.update_documents, name='update_documents'),

]




